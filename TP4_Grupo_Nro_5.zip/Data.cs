﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TrabajoPractico4 {
    public class Data {
        public static string NEPTUNO = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=Neptuno;Integrated Security=True";
        public static string LIBRERIA = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=Libreria;Integrated Security=True";
        public static string VIAJES = "Data Source=localhost\\SQLEXPRESS;Initial Catalog=Viajes;Integrated Security=True";
    }
}